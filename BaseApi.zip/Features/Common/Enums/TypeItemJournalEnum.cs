﻿namespace BaseApi.WebApi.Features.Common.Enums
{
    public enum TypeItemJournalEnum {
        Entrada = 1,
        Salida= 2
    }
}
