﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BaseApi.WebApi.Features.Common.Dto;
using BaseApi.WebApi.Features.Common.Entities;
using BaseApi.WebApi.Helpers;
using BaseApi.WebApi.Infraestructure;
using Microsoft.AspNetCore.Http;

namespace BaseApi.WebApi.Features.Common
{
    public class CommonService
    {
        private readonly BaseApiDbContext _baseApiDbContext;
        public CommonService(BaseApiDbContext logisticaBtdDbContext)
        {
            _baseApiDbContext = logisticaBtdDbContext;
        }
 
  
     

       
       
        
       
        

    }
}
