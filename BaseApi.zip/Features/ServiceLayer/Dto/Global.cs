﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BaseApi.WebApi.Features.ServiceLayer.Dto
{
    public class Global
    {
        public static string sURL = "https://10.0.0.32:50000/b1s/v1/";
        public static string sCompany = "PRUEBAS_INTERCOSMO";
        public static string sUser = "sistemas";
        public static string sPassword = "methos";
        public static string sDataBasePass = "Cham1nt3r2021*.*";
        public static string sDataBaseUser = "SYSTEM";
        public static string sDataBaseServer = "10.0.0.32:30013";
    }
}
