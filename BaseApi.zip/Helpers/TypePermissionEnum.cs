﻿using System;
namespace BaseApi.WebApi.Helpers
{
    public enum TypePermissionEnum : int
    {
        Pantalla = 1,
        Boton = 2,
    }
}
